with open('links.json', 'r+') as reader:
    lines = reader.readlines()

link_list = [line for line in lines if 'http' in str(
    line) or 'https' in str(line)]


link_file = 'links.md'

with open(link_file, 'w+') as writer:
    for link in link_list:
        writer.write(str(link))
        # writer.write('\n')
