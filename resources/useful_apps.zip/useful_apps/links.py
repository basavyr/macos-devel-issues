with open('links.json', 'r+') as reader:
    lines = reader.readlines()

link_list = [line for line in lines if 'http' in str(
    line) or 'https' in str(line)]


link_file = 'links.md'


link_list = [link.strip().split(' ') for link in link_list]


pure_links = []

for link in link_list:
    x = [sub_link.strip(",\"") for sub_link in link[1:]
         if 'http' in sub_link or 'https' in sub_link]
    pure_links.append(x[0])



with open(link_file, 'w+') as writer:
    for link in pure_links:
        writer.write(str(link))
        writer.write('\n')
