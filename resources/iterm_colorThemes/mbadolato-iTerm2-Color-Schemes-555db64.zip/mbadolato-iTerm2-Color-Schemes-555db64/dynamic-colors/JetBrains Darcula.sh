#!/bin/sh
# JetBrains Darcula
printf "\033]4;0;#000000;1;#fa5355;2;#126e00;3;#c2c300;4;#4581eb;5;#fa54ff;6;#33c2c1;7;#adadad;8;#555555;9;#fb7172;10;#67ff4f;11;#ffff00;12;#6d9df1;13;#fb82ff;14;#60d3d1;15;#eeeeee\007"
printf "\033]10;#adadad;#202020;#ffffff\007"
printf "\033]17;#1a3272\007"
printf "\033]19;#adadad\007"
printf "\033]5;0;#eeeeee\007"
