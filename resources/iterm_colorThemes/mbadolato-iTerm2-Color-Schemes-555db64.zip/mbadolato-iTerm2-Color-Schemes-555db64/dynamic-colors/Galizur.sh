#!/bin/sh
# Galizur
printf "\033]4;0;#223344;1;#aa1122;2;#33aa11;3;#ccaa22;4;#2255cc;5;#7755aa;6;#22bbdd;7;#8899aa;8;#556677;9;#ff1133;10;#33ff11;11;#ffdd33;12;#3377ff;13;#aa77ff;14;#33ddff;15;#bbccdd\007"
printf "\033]10;#ddeeff;#071317;#ddeeff\007"
printf "\033]17;#071317\007"
printf "\033]19;#ddeeff\007"
printf "\033]5;0;#ddeeff\007"
