#!/bin/sh
# Red Sands
printf "\033]4;0;#000000;1;#ff3f00;2;#00bb00;3;#e7b000;4;#0072ff;5;#bb00bb;6;#00bbbb;7;#bbbbbb;8;#555555;9;#bb0000;10;#00bb00;11;#e7b000;12;#0072ae;13;#ff55ff;14;#55ffff;15;#ffffff\007"
printf "\033]10;#d7c9a7;#7a251e;#ffffff\007"
printf "\033]17;#a4a390\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#dfbd22\007"
