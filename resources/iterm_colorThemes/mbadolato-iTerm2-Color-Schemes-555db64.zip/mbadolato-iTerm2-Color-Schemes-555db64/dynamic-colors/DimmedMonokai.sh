#!/bin/sh
# DimmedMonokai
printf "\033]4;0;#3a3d43;1;#be3f48;2;#879a3b;3;#c5a635;4;#4f76a1;5;#855c8d;6;#578fa4;7;#b9bcba;8;#888987;9;#fb001f;10;#0f722f;11;#c47033;12;#186de3;13;#fb0067;14;#2e706d;15;#fdffb9\007"
printf "\033]10;#b9bcba;#1f1f1f;#f83e19\007"
printf "\033]17;#2a2d32\007"
printf "\033]19;#b9bcba\007"
printf "\033]5;0;#feffb2\007"
