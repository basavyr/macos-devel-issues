#!/bin/sh
# Spacedust
printf "\033]4;0;#6e5346;1;#e35b00;2;#5cab96;3;#e3cd7b;4;#0f548b;5;#e35b00;6;#06afc7;7;#f0f1ce;8;#684c31;9;#ff8a3a;10;#aecab8;11;#ffc878;12;#67a0ce;13;#ff8a3a;14;#83a7b4;15;#fefff1\007"
printf "\033]10;#ecf0c1;#0a1e24;#708284\007"
printf "\033]17;#0a385c\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
