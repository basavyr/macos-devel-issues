#!/bin/sh
# Batman
printf "\033]4;0;#1b1d1e;1;#e6dc44;2;#c8be46;3;#f4fd22;4;#737174;5;#747271;6;#62605f;7;#c6c5bf;8;#505354;9;#fff78e;10;#fff27d;11;#feed6c;12;#919495;13;#9a9a9d;14;#a3a3a6;15;#dadbd6\007"
printf "\033]10;#6f6f6f;#1b1d1e;#fcef0c\007"
printf "\033]17;#4d504c\007"
printf "\033]19;#f0e04a\007"
printf "\033]5;0;#ffffff\007"
