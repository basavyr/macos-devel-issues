#!/bin/sh
# SpaceGray Eighties
printf "\033]4;0;#15171c;1;#ec5f67;2;#81a764;3;#fec254;4;#5486c0;5;#bf83c1;6;#57c2c1;7;#efece7;8;#555555;9;#ff6973;10;#93d493;11;#ffd256;12;#4d84d1;13;#ff55ff;14;#83e9e4;15;#ffffff\007"
printf "\033]10;#bdbaae;#222222;#bbbbbb\007"
printf "\033]17;#272e35\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
