#!/bin/sh
# BlueBerryPie
printf "\033]4;0;#0a4c62;1;#99246e;2;#5cb1b3;3;#eab9a8;4;#90a5bd;5;#9d54a7;6;#7e83cc;7;#f0e8d6;8;#201637;9;#c87272;10;#0a6c7e;11;#7a3188;12;#39173d;13;#bc94b7;14;#5e6071;15;#0a6c7e\007"
printf "\033]10;#babab9;#1c0c28;#fcfad6\007"
printf "\033]17;#606060\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#eaeaea\007"
