#!/bin/sh
# Mariana
printf "\033]4;0;#000000;1;#ec5f66;2;#99c794;3;#f9ae58;4;#6699cc;5;#c695c6;6;#5fb4b4;7;#f7f7f7;8;#333333;9;#f97b58;10;#acd1a8;11;#fac761;12;#85add6;13;#d8b6d8;14;#82c4c4;15;#ffffff\007"
printf "\033]10;#d8dee9;#343d46;#fcbb6a\007"
printf "\033]17;#4e5a65\007"
printf "\033]19;#d8dee9\007"
printf "\033]5;0;#ffffff\007"
