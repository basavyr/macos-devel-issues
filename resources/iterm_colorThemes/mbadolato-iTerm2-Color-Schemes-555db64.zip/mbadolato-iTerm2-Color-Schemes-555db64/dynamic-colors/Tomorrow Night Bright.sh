#!/bin/sh
# Tomorrow Night Bright
printf "\033]4;0;#000000;1;#d54e53;2;#b9ca4a;3;#e7c547;4;#7aa6da;5;#c397d8;6;#70c0b1;7;#ffffff;8;#000000;9;#d54e53;10;#b9ca4a;11;#e7c547;12;#7aa6da;13;#c397d8;14;#70c0b1;15;#ffffff\007"
printf "\033]10;#eaeaea;#000000;#eaeaea\007"
printf "\033]17;#424242\007"
printf "\033]19;#eaeaea\007"
printf "\033]5;0;#eaeaea\007"
