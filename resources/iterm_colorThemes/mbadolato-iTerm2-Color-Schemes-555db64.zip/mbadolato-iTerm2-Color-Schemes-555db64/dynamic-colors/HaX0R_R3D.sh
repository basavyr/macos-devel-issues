#!/bin/sh
# HaX0R_R3D
printf "\033]4;0;#1f0000;1;#b00d0d;2;#b00d0d;3;#b00d0d;4;#b00d0d;5;#b00d0d;6;#b00d0d;7;#fafafa;8;#150000;9;#ff1111;10;#ff1010;11;#ff1010;12;#ff1010;13;#ff1010;14;#ff1010;15;#fefefe\007"
printf "\033]10;#b10e0e;#200101;#b00d0d\007"
printf "\033]17;#ebc1ff\007"
printf "\033]19;#fdfdfd\007"
printf "\033]5;0;#ff0000\007"
