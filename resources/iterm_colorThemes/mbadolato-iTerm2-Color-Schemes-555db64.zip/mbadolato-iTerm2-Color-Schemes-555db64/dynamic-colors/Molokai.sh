#!/bin/sh
# Molokai
printf "\033]4;0;#121212;1;#fa2573;2;#98e123;3;#dfd460;4;#1080d0;5;#8700ff;6;#43a8d0;7;#bbbbbb;8;#555555;9;#f6669d;10;#b1e05f;11;#fff26d;12;#00afff;13;#af87ff;14;#51ceff;15;#ffffff\007"
printf "\033]10;#bbbbbb;#121212;#bbbbbb\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
