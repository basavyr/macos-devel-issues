#!/bin/sh
# Raycast_Light
printf "\033]4;0;#000000;1;#b12424;2;#006b4f;3;#f8a300;4;#138af2;5;#9a1b6e;6;#3eb8bf;7;#ffffff;8;#000000;9;#b12424;10;#006b4f;11;#f8a300;12;#138af2;13;#9a1b6e;14;#3eb8bf;15;#ffffff\007"
printf "\033]10;#000000;#ffffff;#000000\007"
printf "\033]17;#e5e5e5\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
