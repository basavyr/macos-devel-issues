#!/bin/sh
# Ayu Mirage
printf "\033]4;0;#191e2a;1;#ed8274;2;#a6cc70;3;#fad07b;4;#6dcbfa;5;#cfbafa;6;#90e1c6;7;#c7c7c7;8;#686868;9;#f28779;10;#bae67e;11;#ffd580;12;#73d0ff;13;#d4bfff;14;#95e6cb;15;#ffffff\007"
printf "\033]10;#cbccc6;#1f2430;#ffcc66\007"
printf "\033]17;#33415e\007"
printf "\033]19;#cbccc6\007"
printf "\033]5;0;#ffffff\007"
