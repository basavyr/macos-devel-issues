#!/bin/sh
# Medallion
printf "\033]4;0;#000000;1;#b64c00;2;#7c8b16;3;#d3bd26;4;#616bb0;5;#8c5a90;6;#916c25;7;#cac29a;8;#5e5219;9;#ff9149;10;#b2ca3b;11;#ffe54a;12;#acb8ff;13;#ffa0ff;14;#ffbc51;15;#fed698\007"
printf "\033]10;#cac296;#1d1908;#d3ba30\007"
printf "\033]17;#626dac\007"
printf "\033]19;#cac29a\007"
printf "\033]5;0;#ffd890\007"
