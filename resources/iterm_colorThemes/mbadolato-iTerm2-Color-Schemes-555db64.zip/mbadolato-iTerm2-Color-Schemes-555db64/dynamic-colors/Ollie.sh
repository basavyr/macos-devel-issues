#!/bin/sh
# Ollie
printf "\033]4;0;#000000;1;#ac2e31;2;#31ac61;3;#ac4300;4;#2d57ac;5;#b08528;6;#1fa6ac;7;#8a8eac;8;#5b3725;9;#ff3d48;10;#3bff99;11;#ff5e1e;12;#4488ff;13;#ffc21d;14;#1ffaff;15;#5b6ea7\007"
printf "\033]10;#8a8dae;#222125;#5b6ea7\007"
printf "\033]17;#1e3a66\007"
printf "\033]19;#8a8eac\007"
printf "\033]5;0;#5c6dac\007"
