#!/bin/sh
# BlulocoDark
printf "\033]4;0;#41444d;1;#fc2f52;2;#25a45c;3;#ff936a;4;#3476ff;5;#7a82da;6;#4483aa;7;#cdd4e0;8;#8f9aae;9;#ff6480;10;#3fc56b;11;#f9c859;12;#10b1fe;13;#ff78f8;14;#5fb9bc;15;#ffffff\007"
printf "\033]10;#b9c0cb;#282c34;#ffcc00\007"
printf "\033]17;#b9c0ca\007"
printf "\033]19;#272b33\007"
printf "\033]5;0;#ffffff\007"
