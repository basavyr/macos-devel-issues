#!/bin/sh
# UltraViolent
printf "\033]4;0;#242728;1;#ff0090;2;#b6ff00;3;#fff727;4;#47e0fb;5;#d731ff;6;#0effbb;7;#e1e1e1;8;#636667;9;#fb58b4;10;#deff8c;11;#ebe087;12;#7fecff;13;#e681ff;14;#69fcd3;15;#f9f9f5\007"
printf "\033]10;#c1c1c1;#242728;#c1c1c1\007"
printf "\033]17;#574c49\007"
printf "\033]19;#c3c7cb\007"
printf "\033]5;0;#ffffff\007"
