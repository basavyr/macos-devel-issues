#!/bin/sh
# Bright Lights
printf "\033]4;0;#191919;1;#ff355b;2;#b7e876;3;#ffc251;4;#76d4ff;5;#ba76e7;6;#6cbfb5;7;#c2c8d7;8;#191919;9;#ff355b;10;#b7e876;11;#ffc251;12;#76d5ff;13;#ba76e7;14;#6cbfb5;15;#c2c8d7\007"
printf "\033]10;#b3c9d7;#191919;#f34b00\007"
printf "\033]17;#b3c9d7\007"
printf "\033]19;#191919\007"
printf "\033]5;0;#9fb3c1\007"
