#!/bin/sh
# Fairyfloss
printf "\033]4;0;#040303;1;#f92672;2;#c2ffdf;3;#e6c000;4;#c2ffdf;5;#ffb8d1;6;#c5a3ff;7;#f8f8f0;8;#6090cb;9;#ff857f;10;#c2ffdf;11;#ffea00;12;#c2ffdf;13;#ffb8d1;14;#c5a3ff;15;#f8f8f0\007"
printf "\033]10;#f8f8f2;#5a5475;#f8f8f0\007"
printf "\033]17;#8077a8\007"
printf "\033]19;#f6e1ce\007"
printf "\033]5;0;#ff857f\007"
