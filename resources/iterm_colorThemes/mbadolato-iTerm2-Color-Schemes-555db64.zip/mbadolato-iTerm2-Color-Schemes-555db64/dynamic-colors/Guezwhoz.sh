#!/bin/sh
# Guezwhoz
printf "\033]4;0;#080808;1;#ff5f5f;2;#87d7af;3;#d7d787;4;#5fafd7;5;#afafff;6;#5fd7d7;7;#dadada;8;#8a8a8a;9;#d75f5f;10;#afd7af;11;#d7d7af;12;#87afd7;13;#afafd7;14;#87d7d7;15;#dadada\007"
printf "\033]10;#d0d0d0;#1c1c1c;#eeeeee\007"
printf "\033]17;#005f5f\007"
printf "\033]19;#eeeeee\007"
printf "\033]5;0;#eeeeee\007"
